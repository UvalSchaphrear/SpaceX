
const axios = require('axios')

export const landingService = {
    getLandings,
}

// getLandings()

export async function getLandings() {
    try {
        const res = await axios.get(`https://api.spacexdata.com/v4/launches`)
        const launches = res.data
        const flights = launches.filter(launch => {
            if (launch.cores[0].landing_attempt) return launch
        })
        console.log(flights);
        return flights
    } catch (err) {
        console.log('Error getting landings:', err)
    }
}

function removeLanding(landingId) {


}